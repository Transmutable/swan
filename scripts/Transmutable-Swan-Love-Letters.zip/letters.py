LETTERS = [
    [
        "",
        "I only have eyes",
        "for you."
    ],
    [
        "",
        "You are seen",
        "and loved."
    ],
    [
        "The day we met",
        "was pretty lucky",
        "because we found",
        "each other."
    ],
    [
        "If the stars fell",
        "I'd use a big",
        "flashlight to find",
        "you.",
    ],
    [
        "",
        "Your morning breath",
        "is no big deal.",
    ],
    [
        "",
        "Thank dog for",
        "the house cleaner.",
    ],
]
